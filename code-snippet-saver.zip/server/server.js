const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

let snippets = [];

app.post("/save", (req, res) => {
  snippets.push(req.body);
  res.json({ message: "Saved" });
});

app.get("/snippets", (req, res) => {
  res.json(snippets);
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});
