function saveSnippet() {

  const title = document.getElementById("title").value;
  const code = document.getElementById("code").value;

  fetch("http://localhost:3000/save", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ title, code })
  })
  .then(res => res.json())
  .then(() => loadSnippets());

}

function loadSnippets() {

  fetch("http://localhost:3000/snippets")
  .then(res => res.json())
  .then(data => {

    const list = document.getElementById("list");
    list.innerHTML = "";

    data.forEach(item => {

      const li = document.createElement("li");
      li.innerText = item.title + ": " + item.code;
      list.appendChild(li);

    });

  });

}

loadSnippets();
