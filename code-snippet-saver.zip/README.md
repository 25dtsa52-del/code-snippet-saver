# Code Snippet Saver

A full-stack web application to save and manage code snippets.

## Technologies Used
- HTML
- CSS
- JavaScript
- Node.js
- Express.js

## How to Run
1. Install Node.js
2. Run: npm install express cors
3. Start server: node server/server.js
4. Open public/index.html in browser
